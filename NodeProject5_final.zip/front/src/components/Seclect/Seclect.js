import React from "react";
import styled, { css } from "styled-components";


const StyledSelect = styled.select`
  background:#fff;
  border:2px solid #9CD5C2;
  color: #9CD5C2;
  border-radius:1rem;
  font-size:17px;
  padding:7px 0;
  cursor:pointer;
  outline:none;
  text-align:center;
  option{
    font-size:17px;
    cursor:pointer;
  }
`;

function Select({ children,...props }) {
  function selectEvent(e){
    let selVal = document.querySelector('option');
    console.log(e.value);
    console.log(selVal.vlaue);
    // console.log(e.options[e.selectedIndex].text);
  }
  return(
    <StyledSelect onChange={selectEvent}>
      <option value="" selected disabled>주종을 선택하세요.</option>
      <option value="wine">와인🍷</option>
      <option value="beer">맥주</option>
      <option value="soju">소주🥛</option>
      <option value="cocktail">칵테일🍹</option>
      <option value="mack">막걸리</option>
    </StyledSelect>
  );
  
}
export default Select;
